#!/bin/bash
INSTALL_PAD="/usr/bin"
VERSION=$(grep '\"v[0-9]' 485solar-get.c|awk -F\" '{print $2}'|sed 's/v//')

echo "Compiling and installing 485solar-get version ${VERSION} ..."
if [ -f ../libs/libyasdimaster.c ]
then
  echo "yasdi library found"
  if gcc 485solar-get.c -I../include/ -I../smalib -I../libs -o 485solar-get -lyasdimaster
  then
    echo Compilation OK
    if [ ! -f /etc/yasdi.ini ]
    then
      cp yasdi.ini /etc/yasdi.ini 
    fi
    echo "did you already configure /etc/yasdi.ini ?"
    echo ""
    printf "Installing ${INSTALL_PAD}/485solar-get (with lock_check) ."
    copy_ok=0
    485solar-get -x
    while [ $copy_ok == 0 ]
    do
      if cp 485solar-get ${INSTALL_PAD}/485solar-get 2>/dev/null
      then
        copy_ok=1
      else
        printf "."
        sleep 1
      fi
    done
    echo "OK"
  else
    echo Compilation ERROR
  fi
else
  echo "ERROR, no yasdi library found"
fi

