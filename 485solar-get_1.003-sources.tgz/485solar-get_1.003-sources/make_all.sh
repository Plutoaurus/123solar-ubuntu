#!/bin/bash

485SOLAR_PATH=$(pwd)
./make_deb.sh
./make_tarball.sh 

ssh ubuntui386 <<EOF
rm -rf ${485SOLAR_PATH}/DEBIAN
rm -rf ${485SOLAR_PATH}/System
rm -rf ${485SOLAR_PATH}/lib
mkdir ${485SOLAR_PATH}
EOF
scp -rp ./* ubuntui386:${485SOLAR_PATH}

ssh ubuntui386 <<EOF
cd ${485SOLAR_PATH}
./make_deb.sh
./make_tarball.sh 
EOF
485solar-get -v 
ssh ubuntui386 485solar-get -v

