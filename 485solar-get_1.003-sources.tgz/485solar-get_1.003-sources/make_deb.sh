#!/bin/bash
VERSION=$(grep '\"v[0-9]' 485solar-get.c|tail -1|awk -F\" '{print $2}'|sed 's/v//')
ARCH=$(dpkg-deb --version|grep '('|sed 's/)/(/g'|awk -F\( '{print $2}')
DIST=$(egrep "DISTRIB_ID|DISTRIB_RELEASE" /etc/*-release|awk -F= '{printf $2" "}'|sed 's/\./_/g;s/ /_/g;s/_$//')
NAME="485solar-get"
PNAME="$(echo ${NAME}|sed 's/[ _]/-/g')"
PACKAGE_PAD="/home/pi/485solar-get"

echo "Building ${NAME} ..."
mkdir "tmp"
cd "tmp"
mkdir DEBIAN
mkdir -p usr/bin usr/local/lib etc
chmod -R 775 DEBIAN usr
echo "Package: ${PNAME}
Version: ${VERSION}
Homepage: http://code.google.com/p/485solar-get/
Architecture: ${ARCH}
Maintainer: Roland Breedveld <roland@breedveld.net>
Section: Roland Breedveld
Description: ${NAME} gets data from yout sma inverter via RS485.
" > DEBIAN/control
echo "#!/bin/sh
set -e
# Automatically added by dh_makeshlibs
if [ \"\$1\" = \"configure\" ]; then
	ldconfig
fi
# End automatically added section">DEBIAN/postinst 

echo "#!/bin/sh
set -e
# Automatically added by dh_makeshlibs
if [ \"\$1\" = \"remove\" ]; then
	ldconfig
fi
# End automatically added section">DEBIAN/postrm
chmod 775 DEBIAN/p*

echo "/etc/yasdi.ini">DEBIAN/conffiles 

cp ../485solar-get ./usr/bin/
cp ../yasdi.ini ./etc/
find ../../projects/generic-cmake/build-gcc/ -name libyas*so* -type f -exec cp -rp {} ./usr/local/lib/ \;
cd usr/local/lib
ln -s libyasdi_drv_serial.so.1.8.1 libyasdi_drv_serial.so.1
ln -s libyasdi_drv_ip.so.1.8.1 libyasdi_drv_ip.so.1
ln -s libyasdi.so.1.8.1 libyasdi.so.1
ln -s libyasdimaster.so.1.8.1 libyasdimaster.so.1
ln -s libyasdi_drv_serial.so.1 libyasdi_drv_serial.so
ln -s libyasdi_drv_ip.so.1 libyasdi_drv_ip.so
ln -s libyasdi.so.1 libyasdi.so
ln -s libyasdimaster.so.1 libyasdimaster.so
cd -

cd ../
echo "Building Package ..."
if [ "${ARCH}" == "armhf" ]
then
  ARCH="${ARCH}32"
fi
dpkg-deb -b ./tmp ${PACKAGE_PAD}/485solar-get-${VERSION}-${ARCH}.deb
echo "Ready, file and content:"
echo "Package generated: ${PACKAGE_PAD}/485solar-get-${VERSION}-${ARCH}.deb"
echo "Package content:"
dpkg -c ${PACKAGE_PAD}/485solar-get-${VERSION}-${ARCH}.deb

rm -rf ./tmp
