#!/bin/bash

export INSTALL_PAD=/usr/bin
export YASDI_LIB_PAD=/usr/local/lib

if [ -f "${YASDI_LIB_PAD}/libyasdi_drv_serial.so.1.8.1" ]
then
  echo "libyasdi librarys already installed"
else
  echo "Installing libyasdi librarys"
  cp ./lib/libyasdimaster.so.1.8.1 ${YASDI_LIB_PAD}/
  cp ./lib/libyasdi.so.1.8.1 ${YASDI_LIB_PAD}/
  cp ./lib/libyasdi_drv_serial.so.1.8.1 ${YASDI_LIB_PAD}/
  cp ./lib/libyasdi_drv_ip.so.1.8.1 ${YASDI_LIB_PAD}/
  ln -s ${YASDI_LIB_PAD}/libyasdi_drv_serial.so.1.8.1 ${YASDI_LIB_PAD}/libyasdi_drv_serial.so.1
  ln -s ${YASDI_LIB_PAD}/libyasdi_drv_ip.so.1.8.1 ${YASDI_LIB_PAD}/libyasdi_drv_ip.so.1
  ln -s ${YASDI_LIB_PAD}/libyasdi.so.1.8.1 ${YASDI_LIB_PAD}/libyasdi.so.1
  ln -s ${YASDI_LIB_PAD}/libyasdimaster.so.1.8.1 ${YASDI_LIB_PAD}/libyasdimaster.so.1
  ln -s ${YASDI_LIB_PAD}/libyasdi_drv_serial.so.1 ${YASDI_LIB_PAD}/libyasdi_drv_serial.so
  ln -s ${YASDI_LIB_PAD}/libyasdi_drv_ip.so.1 ${YASDI_LIB_PAD}/libyasdi_drv_ip.so
  ln -s ${YASDI_LIB_PAD}/libyasdi.so.1 ${YASDI_LIB_PAD}/libyasdi.so
  ln -s ${YASDI_LIB_PAD}/libyasdimaster.so.1 ${YASDI_LIB_PAD}/libyasdimaster.so
fi

if ldconfig -p|grep libyasdi >/dev/null 2>&1
then
  echo "yasdi librarys found with ldconfig"
else
  echo "configurationg yasdi librarys with ldconfig"
  ldconfig /usr/local/lib
fi


if [ ! -f /etc/yasdi.ini ]
then
  cp yasdi.ini /etc/yasdi.ini 
fi
echo "Is /etc/yasdi.ini already configured?"

printf "Installing ${INSTALL_PAD}/485solar-get (with lock_check) ."
copy_ok=0
485solar-get -x
while [ $copy_ok == 0 ]
do
  if cp 485solar-get ${INSTALL_PAD}/485solar-get 2>/dev/null
  then
    copy_ok=1
  else
    printf "."
    sleep 1
  fi
done
echo "OK"

